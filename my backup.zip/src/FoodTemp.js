import * as React from "react";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import {
  CarouselProvider,
  Slider,
  Slide,
  ButtonBack,
  ButtonNext,
} from "pure-react-carousel";
import "pure-react-carousel/dist/react-carousel.es.css";

function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

CustomTabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

function FoodTemp() {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: "100%" }}>
      <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
        <CarouselProvider
          visibleSlides={3}
          totalSlides={6}
          step={1}
          naturalSlideWidth={100}
          naturalSlideHeight={10}
        >
          <Slider>
            <Tabs value={value} onChange={handleChange} aria-label="Categories">
              <Tab label="Item 1" {...a11yProps(0)}>
                <Slide index={0}>1</Slide>
              </Tab>
              <Tab label="Item 2" {...a11yProps(1)}>
                <Slide index={1}>2</Slide>
              </Tab>
              <Tab label="Item 3" {...a11yProps(2)}>
                <Slide index={2}>3</Slide>
              </Tab>
              <Tab label="Item 4" {...a11yProps(3)}>
                <Slide index={3}>4</Slide>
              </Tab>
              <Tab label="Item 5" {...a11yProps(4)}>
                <Slide index={4}>5</Slide>
              </Tab>
              <Tab label="Item 6" {...a11yProps(5)}>
                <Slide index={5}>6</Slide>
              </Tab>
            </Tabs>
          </Slider>
          <ButtonBack>Back</ButtonBack>
          <ButtonNext>Next</ButtonNext>
        </CarouselProvider>
      </Box>
      <CustomTabPanel value={value} index={0}>
        Item 1
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
        Item 2
      </CustomTabPanel>
      <CustomTabPanel value={value} index={2}>
        Item 3
      </CustomTabPanel>
      <CustomTabPanel value={value} index={3}>
        Item 4
      </CustomTabPanel>
      <CustomTabPanel value={value} index={4}>
        Item 5
      </CustomTabPanel>
      <CustomTabPanel value={value} index={5}>
        Item 6
      </CustomTabPanel>
    </Box>
  );
}
export default FoodTemp;
